import './style.css'
import * as THREE from 'three'

document.querySelector('#app').innerHTML = `
  <div id="game">
    <div class="topbar">
      <div class="brand">ESCAPE<span> VELOCITY</span><small>NEON DISTRICT // NIGHT RUN</small></div>
      <div class="status"><i></i><span id="race-status">RACE READY</span></div>
    </div>
    <div class="hud">
      <div class="label">VELOCITY</div>
      <div class="speed"><span id="speed">000</span><small> KM/H</small></div>
      <div class="speedbar"><i id="speed-fill"></i></div>
      <div class="lap">LAP <b id="lap">01</b><span> / 03</span></div>
      <div class="progress"><i id="lap-progress"></i></div>
    </div>
    <div class="center-message" id="message">W / ↑ TO START YOUR RUN</div>
    <div class="bottom">
      <div><kbd>W</kbd> / <kbd>↑</kbd><span>THROTTLE</span></div>
      <div><kbd>A</kbd> <kbd>D</kbd> / <kbd>←</kbd> <kbd>→</kbd><span>STEER</span></div>
      <div><kbd>S</kbd> / <kbd>↓</kbd><span>BRAKE / REVERSE</span></div>
      <div><kbd>SPACE</kbd><span>HANDBRAKE</span></div>
    </div>
    <div class="crosshair">EV <span>// 001</span></div>
    <div class="vignette"></div>
  </div>
`

// ── SCENE, RENDERER, CAMERA ──────────────────────────────────────────
const scene = new THREE.Scene()
scene.background = new THREE.Color('#050710')
scene.fog = new THREE.FogExp2('#0a1024', 0.00052)

const camera = new THREE.PerspectiveCamera(66, innerWidth / innerHeight, 0.1, 4200)
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' })
renderer.setSize(innerWidth, innerHeight)
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.8))
renderer.shadowMap.enabled = true
renderer.shadowMap.type = THREE.PCFShadowMap
renderer.toneMapping = THREE.ACESFilmicToneMapping
renderer.toneMappingExposure = 1.42
renderer.outputColorSpace = THREE.SRGBColorSpace
document.querySelector('#game').prepend(renderer.domElement)

// ── LIGHTING ─────────────────────────────────────────────────────────
scene.add(new THREE.HemisphereLight(0xa9c8ff, 0x171020, 2.15))
scene.add(new THREE.AmbientLight(0x243a70, 0.55))
const moon = new THREE.DirectionalLight(0x9eb9ff, 2.2)
moon.position.set(-160, 300, 90)
moon.castShadow = true
moon.shadow.mapSize.set(1024, 1024)
moon.shadow.camera.left = -100
moon.shadow.camera.right = 100
moon.shadow.camera.top = 100
moon.shadow.camera.bottom = -100
moon.shadow.camera.far = 600
scene.add(moon)
const cyanFill = new THREE.PointLight(0x00dfff, 95, 190)
const pinkFill = new THREE.PointLight(0xff168f, 75, 170)
scene.add(cyanFill, pinkFill)

// ── GROUND ───────────────────────────────────────────────────────────
const ground = new THREE.Mesh(
  new THREE.PlaneGeometry(6000, 6000),
  new THREE.MeshStandardMaterial({ color: '#090c17', roughness: 0.88, metalness: 0.08 })
)
ground.rotation.x = -Math.PI / 2
ground.position.y = -2.4
ground.receiveShadow = true
scene.add(ground)

// ── TRACK CENTERLINE ─────────────────────────────────────────────────
const roadWidth = 20
const halfRoad = roadWidth / 2
const trackNodes = [
  [-250, 0, 170], [-180, 2, 205], [-80, 3, 190], [10, 5, 145],
  [100, 8, 130], [195, 16, 145], [275, 25, 105], [300, 28, 30],
  [265, 24, -45], [195, 15, -72], [145, 7, -135], [100, 5, -220],
  [20, 7, -260], [-65, 12, -230], [-130, 23, -185], [-220, 31, -165],
  [-290, 32, -100], [-280, 22, -25], [-215, 10, 25], [-235, 3, 105]
].map(([x, y, z]) => new THREE.Vector3(x, y, z))
const centerline = new THREE.CatmullRomCurve3(trackNodes, true, 'centripetal', 0.42)
const sampleCount = 720
const trackPoints = Array.from({ length: sampleCount }, (_, i) => centerline.getPointAt(i / sampleCount))
const trackTangents = Array.from({ length: sampleCount }, (_, i) => centerline.getTangentAt(i / sampleCount).normalize())
const trackNormals = trackTangents.map(t => new THREE.Vector3(-t.z, 0, t.x).normalize())
const trackLengths = centerline.getLength()

function offsetPoint(index, lateral = 0, y = 0) {
  const p = trackPoints[(index + sampleCount) % sampleCount]
  const n = trackNormals[(index + sampleCount) % sampleCount]
  return new THREE.Vector3(p.x + n.x * lateral, p.y + y, p.z + n.z * lateral)
}

function ribbonGeometry(lateral, width, y = 0.035, start = 0, end = sampleCount, wrap = false) {
  const positions = [], uvs = [], indices = []
  const count = end - start
  for (let j = 0; j <= count; j++) {
    const i = wrap ? (start + j) % sampleCount : Math.min(start + j, sampleCount - 1)
    const left = offsetPoint(i, lateral - width / 2, y)
    const right = offsetPoint(i, lateral + width / 2, y)
    positions.push(left.x, left.y, left.z, right.x, right.y, right.z)
    uvs.push(0, j / Math.max(count, 1), 1, j / Math.max(count, 1))
    if (j < count) {
      const a = j * 2
      indices.push(a, a + 1, a + 2, a + 1, a + 3, a + 2)
    }
  }
  const geometry = new THREE.BufferGeometry()
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3))
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2))
  geometry.setIndex(indices)
  geometry.computeVertexNormals()
  return geometry
}

// ── ROAD SURFACE ─────────────────────────────────────────────────────
const roadGroup = new THREE.Group()
scene.add(roadGroup)
const asphalt = new THREE.MeshStandardMaterial({ color: '#222632', roughness: 0.72, metalness: 0.19 })
const road = new THREE.Mesh(ribbonGeometry(0, roadWidth, 0), asphalt)
road.receiveShadow = true
roadGroup.add(road)

const shoulderMat = new THREE.MeshStandardMaterial({ color: '#4a3344', roughness: 0.7, metalness: 0.1, emissive: '#1e0716', emissiveIntensity: 0.4 })
for (const side of [-1, 1]) {
  const shoulder = new THREE.Mesh(ribbonGeometry(side * (halfRoad + 0.32), 1.25, 0.015), shoulderMat)
  roadGroup.add(shoulder)
}

const neonMat = (color, intensity = 2.2) => new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: intensity, roughness: 0.32, metalness: 0.12 })
const edgeMat = neonMat('#00dfff', 1.65)
for (const side of [-1, 1]) {
  roadGroup.add(new THREE.Mesh(ribbonGeometry(side * (halfRoad - 0.5), 0.16, 0.075), edgeMat))
}

// Center dashes merge into a pair of continuous guide lines on fast straights.
const markingMat = new THREE.MeshBasicMaterial({ color: '#d1deea' })
const dashGeometries = []
const dashLength = 2.5
const spacing = 7.5
for (let distance = 0; distance < trackLengths; distance += spacing) {
  const start = Math.floor(distance / trackLengths * sampleCount)
  const count = Math.max(2, Math.round(dashLength / trackLengths * sampleCount))
  const geom = ribbonGeometry(0, 0.22, 0.09, start, start + count, true)
  dashGeometries.push(geom)
}
const dashPositions = []
const dashIndexes = []
let vertexOffset = 0
for (const geometry of dashGeometries) {
  const pos = geometry.getAttribute('position').array
  for (let i = 0; i < pos.length; i += 3) dashPositions.push(pos[i], pos[i + 1], pos[i + 2])
  const idx = geometry.index.array
  for (const index of idx) dashIndexes.push(index + vertexOffset)
  vertexOffset += pos.length / 3
  geometry.dispose()
}
const dashGeometry = new THREE.BufferGeometry()
dashGeometry.setAttribute('position', new THREE.Float32BufferAttribute(dashPositions, 3))
dashGeometry.setIndex(dashIndexes)
dashGeometry.computeVertexNormals()
roadGroup.add(new THREE.Mesh(dashGeometry, markingMat))

// Alternating curb blocks follow the edge curvature as two merged ribbon meshes.
const curbMaterials = [new THREE.MeshStandardMaterial({ color: '#f4f5f8', roughness: 0.52, side: THREE.DoubleSide }), new THREE.MeshStandardMaterial({ color: '#e53557', roughness: 0.58, emissive: '#3b0712', emissiveIntensity: 0.35, side: THREE.DoubleSide })]
for (const side of [-1, 1]) {
  for (let color = 0; color < 2; color++) {
    const positions = [], indices = []
    for (let i = color; i < sampleCount; i += 4) {
      const p0 = offsetPoint(i, side * (halfRoad - 1.08), 0.12)
      const p1 = offsetPoint(i, side * (halfRoad - 0.08), 0.12)
      const p2 = offsetPoint(i + 2, side * (halfRoad - 1.08), 0.12)
      const p3 = offsetPoint(i + 2, side * (halfRoad - 0.08), 0.12)
      const base = positions.length / 3
      positions.push(p0.x, p0.y, p0.z, p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, p3.x, p3.y, p3.z)
      indices.push(base, base + 2, base + 1, base + 1, base + 2, base + 3)
    }
    const geometry = new THREE.BufferGeometry()
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3))
    geometry.setIndex(indices)
    geometry.computeVertexNormals()
    roadGroup.add(new THREE.Mesh(geometry, curbMaterials[color]))
  }
}

// Continuous guardrails and low neon edge rails track every bend and rise.
const barrierMat = new THREE.MeshStandardMaterial({ color: '#384052', metalness: 0.78, roughness: 0.3 })
for (const side of [-1, 1]) {
  const railPoints = Array.from({ length: sampleCount + 1 }, (_, i) => offsetPoint(i % sampleCount, side * (halfRoad + 2), 1.1))
  const glowPoints = railPoints.map(p => new THREE.Vector3(p.x, p.y + 0.48, p.z))
  const railCurve = new THREE.CatmullRomCurve3(railPoints, true, 'centripetal')
  const glowCurve = new THREE.CatmullRomCurve3(glowPoints, true, 'centripetal')
  const rail = new THREE.Mesh(new THREE.TubeGeometry(railCurve, sampleCount, 0.48, 6, true), barrierMat)
  rail.castShadow = true
  roadGroup.add(rail)
  roadGroup.add(new THREE.Mesh(new THREE.TubeGeometry(glowCurve, sampleCount, 0.065, 5, true), neonMat(side < 0 ? '#ff168f' : '#00dfff', 1.5)))
}

// ── ELEVATED HIGHWAY PIERS, STREETLIGHTS, GANTRIES ───────────────────
const pierGeo = new THREE.CylinderGeometry(1.5, 2.2, 1, 8)
const pierMat = new THREE.MeshStandardMaterial({ color: '#33374a', roughness: 0.6, metalness: 0.4 })
const poleGeo = new THREE.CylinderGeometry(0.16, 0.27, 10, 7)
const poleMat = new THREE.MeshStandardMaterial({ color: '#344056', roughness: 0.38, metalness: 0.8 })
const lampGeo = new THREE.BoxGeometry(2.4, 0.18, 0.55)
const lampEmissive = new THREE.MeshBasicMaterial({ color: '#c7faff' })
for (let i = 0; i < sampleCount; i += 12) {
  const t = i / sampleCount
  const point = trackPoints[i]
  const normal = trackNormals[i]
  if (point.y > 7) {
    for (const side of [-1, 1]) {
      const x = point.x + normal.x * side * (halfRoad + 3)
      const z = point.z + normal.z * side * (halfRoad + 3)
      const pier = new THREE.Mesh(pierGeo, pierMat)
      pier.position.set(x, point.y / 2 - 0.1, z)
      pier.scale.y = Math.max(0.5, point.y + 2)
      roadGroup.add(pier)
    }
  }
  if (i % 24 === 0) {
    for (const side of [-1, 1]) {
      const p = offsetPoint(i, side * (halfRoad + 7), 5)
      const pole = new THREE.Mesh(poleGeo, poleMat)
      pole.position.set(p.x, p.y + 4, p.z)
      pole.castShadow = true
      roadGroup.add(pole)
      const arm = new THREE.Mesh(new THREE.BoxGeometry(3.5, 0.16, 0.2), poleMat)
      arm.position.set(p.x - normal.x * side * 1.2, p.y + 8.8, p.z - normal.z * side * 1.2)
      arm.rotation.y = Math.atan2(normal.x * side, normal.z * side)
      roadGroup.add(arm)
      const lamp = new THREE.Mesh(lampGeo, lampEmissive)
      lamp.position.set(arm.position.x, arm.position.y - 0.1, arm.position.z)
      lamp.rotation.y = arm.rotation.y
      roadGroup.add(lamp)
      // Road-illumination point lights at regular intervals
      if (i % 48 === 0 && side === 1) {
        const light = new THREE.PointLight(0x78dfff, 14, 38)
        light.position.set(lamp.position.x, lamp.position.y - 2, lamp.position.z)
        roadGroup.add(light)
      }
    }
  }
}

function addGantry(t, color = '#00dfff', tunnel = false) {
  const index = Math.round(t * sampleCount) % sampleCount
  const p = trackPoints[index], tangent = trackTangents[index], normal = trackNormals[index]
  const group = new THREE.Group()
  group.position.set(p.x, p.y, p.z)
  group.rotation.y = Math.atan2(tangent.x, tangent.z)
  const frameMat = new THREE.MeshStandardMaterial({ color: '#242c40', metalness: 0.75, roughness: 0.28 })
  const glow = neonMat(color, 2.5)
  const span = new THREE.Mesh(new THREE.BoxGeometry(roadWidth + 7, 0.6, 0.6), frameMat)
  span.position.y = 8.2
  group.add(span)
  for (const side of [-1, 1]) {
    const post = new THREE.Mesh(new THREE.BoxGeometry(0.55, 8.5, 0.6), frameMat)
    post.position.set(side * (halfRoad + 3.5), 4, 0)
    group.add(post)
    const strip = new THREE.Mesh(new THREE.BoxGeometry(0.22, 8.2, 0.7), glow)
    strip.position.set(side * (halfRoad + 3.15), 4, 0)
    group.add(strip)
  }
  const fascia = new THREE.Mesh(new THREE.BoxGeometry(roadWidth + 5, 1.3, 0.8), glow)
  fascia.position.set(0, 7.3, 0)
  group.add(fascia)
  scene.add(group)
  if (tunnel) {
    for (let offset = 13; offset <= 65; offset += 13) {
      const ceiling = new THREE.Mesh(new THREE.BoxGeometry(roadWidth + 8, 0.5, 2.5), frameMat)
      ceiling.position.set(0, 8.8, -offset)
      group.add(ceiling)
      const light = new THREE.Mesh(new THREE.BoxGeometry(4, 0.12, 0.45), lampEmissive)
      light.position.set(0, 8.5, -offset)
      group.add(light)
    }
    const shell = new THREE.Mesh(new THREE.BoxGeometry(roadWidth + 8, 9.5, 70), new THREE.MeshStandardMaterial({ color: '#111627', side: THREE.BackSide, roughness: 0.78 }))
    shell.position.set(0, 4.6, -35)
    group.add(shell)
  }
}
addGantry(0.015, '#00dfff')
addGantry(0.315, '#ff168f')
addGantry(0.72, '#ffb454', true)

// ── CITY SKYLINE ─────────────────────────────────────────────────────
let seed = 3181
function random() { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296 }
const city = new THREE.Group()
scene.add(city)

// nearestTrackPoint is needed during city generation — define it early.
function nearestTrackPoint(position) {
  let bestIndex = 0
  let bestScore = Infinity
  for (let i = 0; i < sampleCount; i += 1) {
    const p = trackPoints[i]
    const dx = position.x - p.x, dz = position.z - p.z
    const dy = position.y - p.y
    const score = dx * dx + dz * dz + dy * dy * 1.7
    if (score < bestScore) { bestScore = score; bestIndex = i }
  }
  const p = trackPoints[bestIndex]
  const tangent = trackTangents[bestIndex]
  const normal = trackNormals[bestIndex]
  const dx = position.x - p.x, dz = position.z - p.z
  const lateral = dx * normal.x + dz * normal.z
  return { index: bestIndex, t: bestIndex / sampleCount, point: p, tangent, lateral, distance: Math.sqrt(bestScore) }
}

const buildingGeo = new THREE.BoxGeometry(1, 1, 1)
const buildingMat = new THREE.MeshStandardMaterial({ color: '#11182a', emissive: '#071127', emissiveIntensity: 0.8, metalness: 0.34, roughness: 0.62 })
const cyanWindows = new THREE.MeshStandardMaterial({ color: '#39dfff', emissive: '#00b9ed', emissiveIntensity: 1.8 })
const amberWindows = new THREE.MeshStandardMaterial({ color: '#ffc06a', emissive: '#ff8b28', emissiveIntensity: 1.4 })
const magentaWindows = new THREE.MeshStandardMaterial({ color: '#ff5cae', emissive: '#fa168b', emissiveIntensity: 1.55 })
const towers = []
const windowBars = [[], [], []]
const sideVariants = [-1, 1]
for (let i = 0; i < 245; i++) {
  const pathIndex = Math.floor(random() * sampleCount)
  const p = trackPoints[pathIndex], n = trackNormals[pathIndex]
  const side = sideVariants[Math.floor(random() * 2)]
  const distance = 90 + Math.pow(random(), 1.7) * 250
  const x = p.x + n.x * side * distance + (random() - 0.5) * 28
  const z = p.z + n.z * side * distance + (random() - 0.5) * 28
  const width = 12 + random() * 34, depth = 12 + random() * 34, height = 24 + Math.pow(random(), 1.4) * 190
  const towerClearance = 48 + Math.max(width, depth) * 0.85
  const towerIsClear = nearestTrackPoint(new THREE.Vector3(x, 0, z)).distance > towerClearance
  if (towerIsClear) {
    towers.push({ x, z, width, depth, height, rotation: random() * Math.PI })
  }
  if (towerIsClear && random() > 0.22) {
    const count = Math.min(5, Math.max(1, Math.floor(height / 36)))
    for (let j = 0; j < count; j++) {
      const matIndex = Math.floor(random() * 3)
      windowBars[matIndex].push({ x: x + (random() - 0.5) * width * 0.62, y: 4 + j * (height / (count + 1)), z: z + depth / 2 + 0.08, width: width * (0.18 + random() * 0.5), rotation: random() * 0.1 })
    }
  }
}
for (let ring = 0; ring < 2; ring++) {
  for (let i = 0; i < 150; i++) {
    const angle = random() * Math.PI * 2
    const radius = 480 + ring * 400 + random() * 300
    const height = 50 + random() * (ring ? 170 : 250)
    towers.push({ x: Math.cos(angle) * radius, z: Math.sin(angle) * radius, width: 20 + random() * 60, depth: 20 + random() * 55, height, rotation: random() * Math.PI })
  }
}
const towerInstances = new THREE.InstancedMesh(buildingGeo, buildingMat, towers.length)
towerInstances.castShadow = false
towerInstances.receiveShadow = true
const dummy = new THREE.Object3D()
towers.forEach((tower, i) => {
  dummy.position.set(tower.x, tower.height / 2 - 2, tower.z)
  dummy.rotation.y = tower.rotation
  dummy.scale.set(tower.width, tower.height, tower.depth)
  dummy.updateMatrix()
  towerInstances.setMatrixAt(i, dummy.matrix)
})
towerInstances.instanceMatrix.needsUpdate = true
city.add(towerInstances)
for (let m = 0; m < windowBars.length; m++) {
  const bars = windowBars[m]
  if (bars.length === 0) continue
  const instances = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), [cyanWindows, amberWindows, magentaWindows][m], bars.length)
  bars.forEach((bar, i) => {
    dummy.position.set(bar.x, bar.y, bar.z)
    dummy.rotation.set(0, bar.rotation, 0)
    dummy.scale.set(bar.width, 1.2, 0.18)
    dummy.updateMatrix()
    instances.setMatrixAt(i, dummy.matrix)
  })
  instances.instanceMatrix.needsUpdate = true
  city.add(instances)
}

// Window-grid texture generated on a small canvas for building facades.
function makeWindowTexture(cols, rows, baseColor, litColor, litChance = 0.35) {
  const cellW = 8, cellH = 12
  const canvas = document.createElement('canvas')
  canvas.width = cols * cellW
  canvas.height = rows * cellH
  const ctx = canvas.getContext('2d')
  ctx.fillStyle = baseColor
  ctx.fillRect(0, 0, canvas.width, canvas.height)
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (random() < litChance) {
        ctx.fillStyle = litColor
        ctx.fillRect(c * cellW + 1, r * cellH + 2, cellW - 2, cellH - 4)
      }
    }
  }
  const tex = new THREE.CanvasTexture(canvas)
  tex.colorSpace = THREE.SRGBColorSpace
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping
  return tex
}

// Create a handful of window-grid textures and place them on the near-track buildings.
const windowTextures = [
  makeWindowTexture(12, 18, '#0a0f1e', '#1abcff', 0.30),
  makeWindowTexture(10, 22, '#0c0c1a', '#ffb84a', 0.25),
  makeWindowTexture(14, 16, '#0b0a1c', '#ff5ca0', 0.28),
]
const windowFacadeMats = windowTextures.map(tex => new THREE.MeshStandardMaterial({
  map: tex, emissiveMap: tex, emissive: '#ffffff', emissiveIntensity: 0.9,
  roughness: 0.7, metalness: 0.15
}))

// Place window-grid facades on near-track buildings for visual richness.
const facadePlanes = []
for (let i = 0; i < Math.min(towers.length, 245); i++) {
  const tower = towers[i]
  if (tower.height < 30 || tower.width < 14) continue
  const matIdx = i % windowFacadeMats.length
  for (let f = 0; f < 2; f++) {
    const w = f === 0 ? tower.width : tower.depth
    const d = f === 0 ? tower.depth : tower.width
    const plane = new THREE.Mesh(
      new THREE.PlaneGeometry(w * 0.92, tower.height * 0.88),
      windowFacadeMats[matIdx]
    )
    const angle = tower.rotation + (f === 0 ? 0 : Math.PI / 2)
    plane.position.set(
      tower.x + Math.sin(angle) * d * 0.502,
      tower.height / 2,
      tower.z + Math.cos(angle) * d * 0.502
    )
    plane.rotation.y = angle + Math.PI
    facadePlanes.push(plane)
    city.add(plane)
  }
  if (facadePlanes.length > 320) break
}

// Local procedural billboard textures keep the city legible without external image assets.
const billboardCanvases = [
  ['NIGHT RUN', 'NEON DISTRICT // 08'],
  ['ESCAPE VELOCITY', 'NO LIMITS AFTER DARK'],
  ['NIGHT CITY', 'KEEP YOUR LINE'],
  ['NITRO // 390', 'RACE THE LIGHTS'],
  ['APEX RUSH', 'TURN THE CITY ON'],
  ['NEON DRIFT', 'ZERO TO INFINITE']
].map(([title, subtitle], i) => {
  const canvas = document.createElement('canvas')
  canvas.width = 1024; canvas.height = 320
  const ctx = canvas.getContext('2d')
  ctx.fillStyle = '#060c1c'; ctx.fillRect(0, 0, canvas.width, canvas.height)
  ctx.strokeStyle = i % 2 ? '#ff168f' : '#00dfff'; ctx.lineWidth = 12; ctx.strokeRect(10, 10, canvas.width - 20, canvas.height - 20)
  ctx.fillStyle = i % 2 ? '#ff6db6' : '#87f5ff'; ctx.font = '800 78px Orbitron, sans-serif'; ctx.fillText(title, 46, 145)
  ctx.fillStyle = '#d3dfef'; ctx.font = '600 34px Orbitron, sans-serif'; ctx.fillText(subtitle, 50, 230)
  const texture = new THREE.CanvasTexture(canvas)
  texture.colorSpace = THREE.SRGBColorSpace
  return texture
})
for (let i = 0; i < 30; i++) {
  const index = Math.floor(i / 30 * sampleCount)
  const p = trackPoints[index], n = trackNormals[index]
  const side = i % 2 ? -1 : 1
  const boardW = 20 + (i % 3) * 4, boardH = 7
  const board = new THREE.Mesh(
    new THREE.PlaneGeometry(boardW, boardH),
    new THREE.MeshBasicMaterial({ map: billboardCanvases[i % billboardCanvases.length], side: THREE.DoubleSide, toneMapped: false })
  )
  board.position.set(p.x + n.x * side * 38, p.y + 14 + (i % 4) * 3, p.z + n.z * side * 38)
  board.rotation.y = Math.atan2(-side * n.x, -side * n.z)
  city.add(board)
  const frame = new THREE.Mesh(new THREE.BoxGeometry(boardW + 0.6, 0.28, 0.28), neonMat(i % 2 ? '#ff168f' : '#00dfff'))
  frame.position.set(board.position.x, board.position.y - boardH / 2 - 0.2, board.position.z)
  frame.rotation.y = board.rotation.y
  city.add(frame)
}

// Distant stars and a low-contrast city haze halo.
const starPositions = []
for (let i = 0; i < 900; i++) {
  const angle = random() * Math.PI * 2
  const radius = 700 + random() * 2600
  starPositions.push(Math.cos(angle) * radius, 150 + random() * 950, Math.sin(angle) * radius)
}
const starGeometry = new THREE.BufferGeometry()
starGeometry.setAttribute('position', new THREE.Float32BufferAttribute(starPositions, 3))
scene.add(new THREE.Points(starGeometry, new THREE.PointsMaterial({ color: '#a3c9ff', size: 2.2, sizeAttenuation: true, transparent: true, opacity: 0.72 })))

// ── SUPERCAR MODEL ───────────────────────────────────────────────────
// Dark metallic supercar with cyan and magenta accent lighting.
const car = new THREE.Group()
scene.add(car)

// Materials palette
const bodyMat = new THREE.MeshPhysicalMaterial({ color: '#1a1e2e', metalness: 0.92, roughness: 0.18, clearcoat: 1.0, clearcoatRoughness: 0.08 })
const accentCyan = new THREE.MeshStandardMaterial({ color: '#00dfff', emissive: '#00dfff', emissiveIntensity: 1.2, metalness: 0.4, roughness: 0.3 })
const accentMagenta = new THREE.MeshStandardMaterial({ color: '#ff168f', emissive: '#ff168f', emissiveIntensity: 1.2, metalness: 0.4, roughness: 0.3 })
const carbonMat = new THREE.MeshStandardMaterial({ color: '#080d18', metalness: 0.68, roughness: 0.3 })
const glassMat = new THREE.MeshPhysicalMaterial({ color: '#061522', metalness: 0.55, roughness: 0.12, clearcoat: 1, transparent: true, opacity: 0.92 })
const rubberMat = new THREE.MeshStandardMaterial({ color: '#05070c', roughness: 0.83 })
const rimMat = new THREE.MeshStandardMaterial({ color: '#9aa9c0', metalness: 0.92, roughness: 0.22 })
const darkMetalMat = new THREE.MeshStandardMaterial({ color: '#252d3e', metalness: 0.88, roughness: 0.28 })
const headlightMat = new THREE.MeshBasicMaterial({ color: '#b9fbff', toneMapped: false })
const taillightMat = new THREE.MeshBasicMaterial({ color: '#ff1744', toneMapped: false })
const taillightGlowMat = new THREE.MeshStandardMaterial({ color: '#ff0033', emissive: '#ff0033', emissiveIntensity: 3.0, roughness: 0.4 })
const underglowMat = new THREE.MeshBasicMaterial({ color: '#ff168f', transparent: true, opacity: 0.28, side: THREE.DoubleSide, depthWrite: false })

function carPart(geometry, material, position, scale, rotation = null) {
  const mesh = new THREE.Mesh(geometry, material)
  mesh.position.set(...position)
  if (scale) mesh.scale.set(...scale)
  if (rotation) mesh.rotation.set(...rotation)
  mesh.castShadow = true
  mesh.receiveShadow = true
  car.add(mesh)
  return mesh
}

// ─── BODY SHELL ──────────────────────────────────────────
// Main central body – wide and low
carPart(new THREE.BoxGeometry(2.04, 0.36, 4.50), bodyMat, [0, 0.66, 0])
// Nose taper — narrowing front section
carPart(new THREE.BoxGeometry(1.82, 0.22, 1.40), bodyMat, [0, 0.82, -1.50])
// Nose tip — low sculpted front
carPart(new THREE.BoxGeometry(1.60, 0.14, 0.60), bodyMat, [0, 0.73, -2.30])
// Rear haunches — wider at back
carPart(new THREE.BoxGeometry(2.12, 0.28, 1.20), bodyMat, [0, 0.78, 1.40])
// Rear deck — raised lip
carPart(new THREE.BoxGeometry(1.90, 0.12, 0.50), bodyMat, [0, 0.94, 1.80])

// ─── FRONT SPLITTER AND AERO ─────────────────────────────
carPart(new THREE.BoxGeometry(2.24, 0.08, 0.38), carbonMat, [0, 0.44, -2.35])
// Front lip — cyan accent line
carPart(new THREE.BoxGeometry(2.0, 0.04, 0.06), accentCyan, [0, 0.45, -2.55])

// ─── SIDE SKIRTS ─────────────────────────────────────────
for (const x of [-1, 1]) {
  carPart(new THREE.BoxGeometry(0.10, 0.18, 3.60), carbonMat, [x * 1.01, 0.47, -0.10])
  // Cyan accent stripe along the side
  carPart(new THREE.BoxGeometry(0.04, 0.06, 2.80), accentCyan, [x * 1.04, 0.55, -0.10])
}

// ─── REAR DIFFUSER ───────────────────────────────────────
carPart(new THREE.BoxGeometry(2.04, 0.10, 0.44), carbonMat, [0, 0.44, 2.30])
// Diffuser fins
for (const x of [-0.52, 0, 0.52]) {
  carPart(new THREE.BoxGeometry(0.04, 0.08, 0.40), darkMetalMat, [x, 0.44, 2.30])
}

// ─── FENDER FLARES / WHEEL ARCHES ────────────────────────
for (const x of [-1, 1]) {
  // Front fender bulge
  carPart(new THREE.BoxGeometry(0.22, 0.26, 0.90), bodyMat, [x * 0.96, 0.68, -1.35])
  // Rear fender bulge — wider
  carPart(new THREE.BoxGeometry(0.26, 0.28, 0.95), bodyMat, [x * 0.98, 0.68, 1.35])
  // Fender vent slats
  carPart(new THREE.BoxGeometry(0.06, 0.10, 0.30), accentCyan, [x * 1.06, 0.72, -0.70])
}

// ─── WINDSHIELD / CANOPY ─────────────────────────────────
const canopyGeometry = new THREE.BufferGeometry()
const canopyVertices = new Float32Array([
  // Windshield face
  -0.76, 0.90, -1.10,   0.76, 0.90, -1.10,   -0.56, 1.50, -0.30,   0.56, 1.50, -0.30,
  // Roof panel
  -0.56, 1.50, -0.30,   0.56, 1.50, -0.30,   -0.62, 1.44, 0.60,   0.62, 1.44, 0.60,
  // Left side glass
  -0.76, 0.90, -1.10,  -0.56, 1.50, -0.30,  -0.62, 1.44, 0.60,  -0.88, 0.90, 0.80,
  // Right side glass
   0.76, 0.90, -1.10,   0.88, 0.90, 0.80,    0.62, 1.44, 0.60,   0.56, 1.50, -0.30,
  // Rear glass
  -0.88, 0.90, 0.80,   -0.62, 1.44, 0.60,    0.62, 1.44, 0.60,   0.88, 0.90, 0.80
])
const canopyIndices = [0,1,2,1,3,2, 4,5,6,5,7,6, 8,9,10,8,10,11, 12,13,14,12,14,15, 16,17,18,16,18,19]
canopyGeometry.setAttribute('position', new THREE.BufferAttribute(canopyVertices, 3))
canopyGeometry.setIndex(canopyIndices)
canopyGeometry.computeVertexNormals()
carPart(canopyGeometry, glassMat, [0, 0, 0])

// Windshield frame
carPart(new THREE.BoxGeometry(1.56, 0.06, 0.08), darkMetalMat, [0, 0.91, -1.10])
// Roof spine
carPart(new THREE.BoxGeometry(0.06, 0.04, 1.30), darkMetalMat, [0, 1.50, 0.08])
// Rear glass frame
carPart(new THREE.BoxGeometry(1.80, 0.06, 0.08), carbonMat, [0, 1.34, 0.72])

// ─── REAR WING ───────────────────────────────────────────
// Wing mounts — two pylons
for (const x of [-0.60, 0.60]) {
  carPart(new THREE.BoxGeometry(0.08, 0.32, 0.08), carbonMat, [x, 1.06, 1.90])
}
// Wing blade — wide and thin
carPart(new THREE.BoxGeometry(2.20, 0.08, 0.36), carbonMat, [0, 1.24, 1.90], null, [-0.06, 0, 0])
// Wing endplates
for (const x of [-1, 1]) {
  carPart(new THREE.BoxGeometry(0.04, 0.14, 0.38), carbonMat, [x * 1.10, 1.22, 1.90])
}
// Wing accent — magenta glow strip
carPart(new THREE.BoxGeometry(1.90, 0.03, 0.06), accentMagenta, [0, 1.18, 2.08])

// ─── WHEELS (4x) ─────────────────────────────────────────
const wheelMeshes = []
const wheelPositions = [
  [-0.94, 0.39, -1.40],
  [ 0.94, 0.39, -1.40],
  [-0.94, 0.39,  1.40],
  [ 0.94, 0.39,  1.40]
]
for (const [wx, wy, wz] of wheelPositions) {
  // Tire
  const wheel = new THREE.Mesh(new THREE.CylinderGeometry(0.39, 0.39, 0.26, 28), rubberMat)
  wheel.rotation.z = Math.PI / 2
  wheel.position.set(wx, wy, wz)
  wheel.castShadow = true
  car.add(wheel)
  wheelMeshes.push(wheel)
  // Rim
  const sideSign = Math.sign(wx)
  const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.27, 24), rimMat)
  rim.rotation.z = Math.PI / 2
  rim.position.set(wx + sideSign * 0.01, wy, wz)
  car.add(rim)
  // Hub
  const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.28, 16), darkMetalMat)
  hub.rotation.z = Math.PI / 2
  hub.position.set(wx + sideSign * 0.02, wy, wz)
  car.add(hub)
  // 5 spokes
  for (let spoke = 0; spoke < 5; spoke++) {
    const angle = spoke * Math.PI * 2 / 5
    const spokeMesh = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.30, 0.04), rimMat)
    spokeMesh.position.set(wx + sideSign * 0.025, wy + Math.sin(angle) * 0.12, wz + Math.cos(angle) * 0.12)
    spokeMesh.rotation.x = -angle
    car.add(spokeMesh)
  }
  // Brake caliper accent — tiny cyan block visible through spokes
  const caliper = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.10, 0.14), accentCyan)
  caliper.position.set(wx + sideSign * 0.015, wy - 0.08, wz)
  car.add(caliper)
}
const wheelMeshesForSpin = wheelMeshes

// ─── HEADLIGHTS ──────────────────────────────────────────
// Dual thin DRL-style headlights — cyan signature
carPart(new THREE.BoxGeometry(0.58, 0.08, 0.05), headlightMat, [-0.52, 0.77, -2.55])
carPart(new THREE.BoxGeometry(0.58, 0.08, 0.05), headlightMat, [ 0.52, 0.77, -2.55])
// Lower headlight accent bars
carPart(new THREE.BoxGeometry(0.40, 0.04, 0.04), accentCyan, [-0.52, 0.70, -2.56])
carPart(new THREE.BoxGeometry(0.40, 0.04, 0.04), accentCyan, [ 0.52, 0.70, -2.56])
// Headlight point light for forward illumination
const headlightGlow = new THREE.PointLight(0x9ef5ff, 12, 25)
headlightGlow.position.set(0, 0.76, -3.0)
car.add(headlightGlow)

// ─── TAILLIGHTS ──────────────────────────────────────────
// Full-width LED tail strip — bright red
carPart(new THREE.BoxGeometry(1.70, 0.08, 0.05), taillightMat, [0, 0.84, 2.32])
// Additional tail glow strips for LED effect
carPart(new THREE.BoxGeometry(0.60, 0.04, 0.04), taillightGlowMat, [-0.42, 0.90, 2.33])
carPart(new THREE.BoxGeometry(0.60, 0.04, 0.04), taillightGlowMat, [ 0.42, 0.90, 2.33])
// Tail light point glow
const tailGlow = new THREE.PointLight(0xff1744, 8, 12)
tailGlow.position.set(0, 0.84, 2.8)
car.add(tailGlow)

// ─── FRONT GRILLE VENTS ──────────────────────────────────
for (const x of [-0.55, -0.28, 0, 0.28, 0.55]) {
  carPart(new THREE.BoxGeometry(0.14, 0.04, 0.04), carbonMat, [x, 0.50, -2.50])
}

// ─── SIDE MARKERS ────────────────────────────────────────
for (const x of [-1, 1]) {
  carPart(new THREE.BoxGeometry(0.06, 0.04, 0.28), accentCyan, [x * 1.04, 0.62, -0.50])
}

// ─── UNDERBODY NEON ──────────────────────────────────────
carPart(new THREE.PlaneGeometry(1.8, 3.80), underglowMat, [0, 0.38, 0], null, [-Math.PI / 2, 0, 0])

// ─── SKID MARKS ──────────────────────────────────────────
const skidMarks = []
for (let i = 0; i < 2; i++) {
  const mark = new THREE.Mesh(new THREE.PlaneGeometry(0.32, 4), new THREE.MeshBasicMaterial({ color: '#15141b', transparent: true, opacity: 0.65, depthWrite: false }))
  mark.rotation.x = -Math.PI / 2
  mark.visible = false
  scene.add(mark)
  skidMarks.push(mark)
}

// ── INITIAL POSITION AND CONTROLS ────────────────────────────────────
const startPoint = centerline.getPointAt(0.015)
const startTangent = centerline.getTangentAt(0.015)
car.position.set(startPoint.x, startPoint.y + 0.03, startPoint.z)
let heading = Math.atan2(startTangent.x, startTangent.z)
car.rotation.y = heading

const keys = {}
addEventListener('keydown', e => {
  keys[e.code] = true
  keys[e.key.toLowerCase()] = true
  if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) e.preventDefault()
})
addEventListener('keyup', e => {
  keys[e.code] = false
  keys[e.key.toLowerCase()] = false
})
addEventListener('blur', () => { for (const key of Object.keys(keys)) keys[key] = false })

let speed = 0
let lap = 1
let lastT = 0.015
let raceStarted = false
let finished = false
let handbrakeWasDown = false
const clock = new THREE.Timer()
const cameraTarget = new THREE.Vector3()
const cameraPos = new THREE.Vector3()
cameraPos.set(
  car.position.x - Math.sin(heading) * 8,
  car.position.y + 4.3,
  car.position.z - Math.cos(heading) * 8
)
camera.position.copy(cameraPos)
camera.lookAt(car.position.x, car.position.y + 0.8, car.position.z)
const speedEl = document.querySelector('#speed')
const speedFill = document.querySelector('#speed-fill')
const lapEl = document.querySelector('#lap')
const lapProgress = document.querySelector('#lap-progress')
const message = document.querySelector('#message')
const statusEl = document.querySelector('#race-status')

function clamp(value, min, max) { return Math.max(min, Math.min(max, value)) }

// ── ANIMATION LOOP ───────────────────────────────────────────────────
function animate() {
  requestAnimationFrame(animate)
  clock.update()
  const dt = Math.min(clock.getDelta(), 0.035)

  // Key inputs — Boolean() prevents NaN from Number(undefined)
  const forward = Boolean(keys.KeyW || keys.w || keys.ArrowUp)
  const reverse = Boolean(keys.KeyS || keys.s || keys.ArrowDown)
  const left = Boolean(keys.KeyA || keys.a || keys.ArrowLeft)
  const right = Boolean(keys.KeyD || keys.d || keys.ArrowRight)
  const handbrake = Boolean(keys.Space)
  if (forward || reverse) raceStarted = true

  // ── PHYSICS ──────────────────────────────────────────────
  if (!finished) {
    if (forward) speed += 39 * dt
    else speed *= Math.pow(0.989, dt * 60)
    if (reverse) speed -= 52 * dt
    speed = clamp(speed, -19, 112)
    if (handbrake) speed *= Math.pow(0.89, dt * 60)
  } else {
    speed *= Math.pow(0.94, dt * 60)
  }

  const steer = Number(right) - Number(left)
  const steeringResponse = 1.5 + Math.abs(speed) * 0.018
  if (left) heading += steeringResponse * dt * Math.sign(speed || 1)
  if (right) heading -= steeringResponse * dt * Math.sign(speed || 1)
  const oldPosition = car.position.clone()
  car.position.x += Math.sin(heading) * speed * dt
  car.position.z += Math.cos(heading) * speed * dt

  const nearest = nearestTrackPoint(car.position)
  const onRoad = Math.abs(nearest.lateral) <= halfRoad + 1.5 && nearest.distance < 18
  if (!onRoad) {
    car.position.copy(oldPosition)
    speed *= -0.22
  }
  const grounded = nearestTrackPoint(car.position)
  car.position.y = THREE.MathUtils.damp(car.position.y, grounded.point.y + 0.03, 9, dt)
  car.rotation.y = heading
  car.rotation.z = THREE.MathUtils.damp(car.rotation.z, steer * -0.035, 8, dt)
  car.rotation.x = THREE.MathUtils.damp(car.rotation.x, grounded.tangent.y * 0.18, 6, dt)
  for (const wheel of wheelMeshesForSpin) wheel.rotation.x -= speed * dt * 1.8

  // ── LAP COUNTING ─────────────────────────────────────────
  if (grounded.distance < 30) {
    if (lastT > 0.82 && grounded.t < 0.18 && speed > 1.5 && !finished) {
      lap += 1
      lapEl.textContent = String(Math.min(lap, 3)).padStart(2, '0')
      if (lap > 3) {
        finished = true
        statusEl.textContent = 'FINISH // RUN COMPLETE'
        message.textContent = 'CITY CONQUERED // RUN COMPLETE'
        message.classList.add('visible')
      }
    }
    if (grounded.t > 0.18 || grounded.t < lastT) lastT = grounded.t
    else lastT = grounded.t
  }
  lapProgress.style.width = `${Math.round(grounded.t * 100)}%`

  // ── HUD UPDATE ───────────────────────────────────────────
  const speedKmh = Math.round(Math.abs(speed) * 3.6)
  speedEl.textContent = String(speedKmh).padStart(3, '0')
  speedFill.style.width = `${Math.min(100, speedKmh / 4.5)}%`
  if (raceStarted && !finished) {
    statusEl.textContent = speedKmh > 320 ? 'MAX VELOCITY' : 'NIGHT RUN // IN PROGRESS'
    message.classList.toggle('visible', speedKmh < 3)
  }

  // ── SKID MARKS ───────────────────────────────────────────
  const justHandbraked = handbrake && !handbrakeWasDown && Math.abs(speed) > 18
  if (justHandbraked) {
    const rear = new THREE.Vector3(0, 0, 2.1).applyAxisAngle(new THREE.Vector3(0, 1, 0), heading).add(car.position)
    for (let i = 0; i < skidMarks.length; i++) {
      skidMarks[i].visible = true
      skidMarks[i].position.set(rear.x + (i ? 0.8 : -0.8) * Math.cos(heading), car.position.y + 0.16, rear.z - (i ? 0.8 : -0.8) * Math.sin(heading))
      skidMarks[i].rotation.z = -heading
    }
  }
  if (!handbrake) skidMarks.forEach(mark => { mark.visible = false })
  handbrakeWasDown = handbrake

  // ── CHASE CAMERA ─────────────────────────────────────────
  // Distance and height adjust subtly with speed for cinematic feel
  const camDist = 8.5 + Math.min(Math.abs(speed) * 0.008, 0.8)
  const camHeight = 4.3 + Math.min(Math.abs(speed) * 0.010, 0.9)
  cameraTarget.set(
    car.position.x - Math.sin(heading) * camDist,
    car.position.y + camHeight,
    car.position.z - Math.cos(heading) * camDist
  )
  cameraPos.lerp(cameraTarget, 1 - Math.exp(-4.5 * dt))
  camera.position.copy(cameraPos)
  cameraTarget.set(car.position.x, car.position.y + 0.8, car.position.z)
  camera.lookAt(cameraTarget)
  camera.fov = THREE.MathUtils.damp(camera.fov, 66 + Math.min(Math.abs(speed) * 0.11, 11), 2.8, dt)
  camera.updateProjectionMatrix()

  // ── FOLLOW LIGHTS ────────────────────────────────────────
  cyanFill.position.set(car.position.x + 18, car.position.y + 16, car.position.z - 22)
  pinkFill.position.set(car.position.x - 22, car.position.y + 13, car.position.z + 26)

  // ── TAILLIGHT INTENSITY — brighter when braking ─────────
  const braking = reverse || handbrake
  tailGlow.intensity = braking ? 18 : 8
  taillightGlowMat.emissiveIntensity = braking ? 5.0 : 3.0

  renderer.render(scene, camera)
}
animate()

addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight
  camera.updateProjectionMatrix()
  renderer.setSize(innerWidth, innerHeight)
})
